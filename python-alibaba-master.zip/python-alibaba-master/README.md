# 阿里巴巴商户采集程序
- 作者:怪咖科学
- 描述:使用Python采集阿里巴巴百万商户
- 网址:http://www.scienceswork.com
- 测试采集数据.csv
   - 这是测试采集数据
- 主程序
   - alibaba.py
   
